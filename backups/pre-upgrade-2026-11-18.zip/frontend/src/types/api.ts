export const modelFeatures = [
  'files_changed',
  'lines_added',
  'avg_files_per_commit',
  'branch_commits',
  'branch_files_changed',
] as const;

export type ModelFeature = (typeof modelFeatures)[number];

export interface HealthResponse {
  status: string;
  service: string;
  model_available: boolean;
}

export interface ReadinessResponse {
  status: string;
  model_available: boolean;
}

export interface ModelInfoResponse {
  model_name: string;
  model_type: string | null;
  model_status: string;
  supported_features: string[];
  supported_feature_count: number;
  feature_contract_size: number;
  class_mapping: Record<string, string>;
  dataset_sha256: string | null;
}

export interface FeatureAggregate {
  name: string;
  observed_count: number;
  missing_count: number;
  minimum: number | null;
  mean: number | null;
  maximum: number | null;
}

export interface DatasetSummaryResponse {
  status: string;
  raw_rows: number;
  processed_rows: number;
  feature_count: number;
  provenance_count: number;
  repository_group_count: number;
  repository_distribution: { group: string; examples: number }[];
  class_counts: Record<string, number>;
  feature_aggregates: FeatureAggregate[];
  collection_timeline: { date: string; examples: number }[];
  raw_available: boolean;
  processed_available: boolean;
}

export type ServiceState = 'checking' | 'connected' | 'offline';

/** The five model inputs are required; the remaining contract fields are optional. */
export interface PredictionRequest {
  files_changed: number;
  lines_added: number;
  avg_files_per_commit: number;
  branch_commits: number;
  branch_files_changed: number;
  commit_severity?: number | null;
  developer_commits?: number | null;
  developer_conflicts?: number | null;
  activity_score?: number | null;
  import_count?: number | null;
  dependency_conflicts?: number | null;
  coverage?: number | null;
  branch_conflicts?: number | null;
  branch_risk_score?: number | null;
  pattern_frequency?: number | null;
  pattern_conflicts?: number | null;
  dependency_risk?: number | null;
  pattern_risk?: number | null;
}

export interface BranchMetadata {
  source: string;
  target: string;
}

export interface PredictionResponse {
  prediction: 0 | 1;
  prediction_label: string;
  predicted_class: 'clean_merge' | 'merge_conflict';
  class_probabilities: {
    clean_merge: number;
    merge_conflict: number;
  };
  probability_note: string;
  model_name: string;
  model_status: string;
  features_used: string[];
  predicted_at: string;
  message: string;
}

export interface SavedPrediction {
  id: string;
  saved_at: string;
  request: PredictionRequest;
  branch_metadata: BranchMetadata;
  response: PredictionResponse;
}

export interface TimedResult<T> {
  data: T | null;
  error: string | null;
  duration_ms: number | null;
}

export interface SystemSnapshot {
  health: TimedResult<HealthResponse>;
  readiness: TimedResult<ReadinessResponse>;
  model_info: TimedResult<ModelInfoResponse>;
  dataset_summary: TimedResult<DatasetSummaryResponse>;
  checked_at: string;
}
