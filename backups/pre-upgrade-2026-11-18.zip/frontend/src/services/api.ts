import type {
  HealthResponse,
  DatasetSummaryResponse,
  ModelInfoResponse,
  PredictionRequest,
  PredictionResponse,
  ReadinessResponse,
  SystemSnapshot,
  TimedResult,
} from '../types/api';
import { modelFeatures } from '../types/api';

const configuredApiBaseUrl = import.meta.env.VITE_API_BASE_URL?.trim();
const developmentApiBaseUrl = import.meta.env.DEV ? 'http://127.0.0.1:8000' : '';

// Keep localhost convenient in Vite development without baking it into a
// production bundle. Production must configure its API origin at build time.
export const apiBaseUrl = (configuredApiBaseUrl || developmentApiBaseUrl).replace(/\/+$/, '');

export class ApiError extends Error {
  constructor(message: string, public readonly status: number, public readonly code?: string) {
    super(message);
    this.name = 'ApiError';
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function numberBetweenZeroAndOne(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1;
}

function errorFromPayload(payload: unknown, status: number): ApiError {
  if (isRecord(payload) && isRecord(payload.error)) {
    const message = typeof payload.error.message === 'string' ? payload.error.message : `The API returned ${status}.`;
    const code = typeof payload.error.code === 'string' ? payload.error.code : undefined;
    return new ApiError(message, status, code);
  }
  if (isRecord(payload) && typeof payload.detail === 'string') return new ApiError(payload.detail, status);
  return new ApiError(`The API returned ${status}.`, status);
}

function validatePredictionResponse(value: unknown): PredictionResponse {
  const features = isRecord(value) ? value.features_used : undefined;
  if (!isRecord(value)
    || (value.prediction !== 0 && value.prediction !== 1)
    || (value.predicted_class !== 'clean_merge' && value.predicted_class !== 'merge_conflict')
    || !isRecord(value.class_probabilities)
    || !numberBetweenZeroAndOne(value.class_probabilities.clean_merge)
    || !numberBetweenZeroAndOne(value.class_probabilities.merge_conflict)
    || Math.abs(value.class_probabilities.clean_merge + value.class_probabilities.merge_conflict - 1) > 1e-5
    || typeof value.prediction_label !== 'string'
    || typeof value.probability_note !== 'string'
    || typeof value.model_name !== 'string'
    || typeof value.model_status !== 'string'
    || !Array.isArray(features)
    || !features.every((feature) => typeof feature === 'string')
    || typeof value.predicted_at !== 'string'
    || typeof value.message !== 'string') {
    throw new ApiError('The API returned a response that does not match the prediction contract.', 502, 'INVALID_API_RESPONSE');
  }
  if (!modelFeatures.every((name) => features.includes(name))) {
    throw new ApiError('The API response does not report the supported model inputs.', 502, 'INVALID_API_RESPONSE');
  }
  return value as unknown as PredictionResponse;
}

async function requestTimed<T>(path: string, validate: (value: unknown) => T): Promise<TimedResult<T>> {
  const start = performance.now();
  try {
    const response = await fetch(`${apiBaseUrl}${path}`, { signal: AbortSignal.timeout(5000) });
    const payload: unknown = await response.json().catch(() => null);
    const duration = Math.round(performance.now() - start);
    if (!response.ok) return { data: null, error: errorFromPayload(payload, response.status).message, duration_ms: duration };
    return { data: validate(payload), error: null, duration_ms: duration };
  } catch (error) {
    const duration = Math.round(performance.now() - start);
    return {
      data: null,
      error: error instanceof Error ? error.message : 'The API request failed.',
      duration_ms: duration,
    };
  }
}

function validateHealth(value: unknown): HealthResponse {
  if (!isRecord(value) || typeof value.status !== 'string' || typeof value.service !== 'string' || typeof value.model_available !== 'boolean') {
    throw new Error('Health response did not match the expected schema.');
  }
  return value as unknown as HealthResponse;
}

function validateReadiness(value: unknown): ReadinessResponse {
  if (!isRecord(value) || typeof value.status !== 'string' || typeof value.model_available !== 'boolean') {
    throw new Error('Readiness response did not match the expected schema.');
  }
  return value as unknown as ReadinessResponse;
}

function validateModelInfo(value: unknown): ModelInfoResponse {
  if (!isRecord(value)
    || typeof value.model_name !== 'string'
    || typeof value.model_status !== 'string'
    || !Array.isArray(value.supported_features)
    || typeof value.supported_feature_count !== 'number'
    || typeof value.feature_contract_size !== 'number'
    || !isRecord(value.class_mapping)) {
    throw new Error('Model information response did not match the expected schema.');
  }
  return value as unknown as ModelInfoResponse;
}

function validateDatasetSummary(value: unknown): DatasetSummaryResponse {
  if (!isRecord(value) || value.status !== 'available'
    || typeof value.raw_rows !== 'number' || typeof value.processed_rows !== 'number'
    || typeof value.feature_count !== 'number' || typeof value.provenance_count !== 'number'
    || typeof value.repository_group_count !== 'number' || !isRecord(value.class_counts)
    || !Array.isArray(value.feature_aggregates) || !Array.isArray(value.repository_distribution)
    || !Array.isArray(value.collection_timeline)) {
    throw new Error('Dataset summary response did not match the expected schema.');
  }
  const classCounts = value.class_counts as Record<string, unknown>;
  if (!['0', '1'].every((label) => typeof classCounts[label] === 'number' && Number.isFinite(classCounts[label]))) {
    throw new Error('Dataset class counts did not match the expected schema.');
  }
  const featureIsValid = (item: unknown) => isRecord(item)
    && typeof item.name === 'string'
    && typeof item.observed_count === 'number' && Number.isFinite(item.observed_count)
    && typeof item.missing_count === 'number' && Number.isFinite(item.missing_count)
    && (item.minimum === null || (typeof item.minimum === 'number' && Number.isFinite(item.minimum)))
    && (item.mean === null || (typeof item.mean === 'number' && Number.isFinite(item.mean)))
    && (item.maximum === null || (typeof item.maximum === 'number' && Number.isFinite(item.maximum)));
  const groupIsValid = (item: unknown) => isRecord(item) && typeof item.group === 'string'
    && typeof item.examples === 'number' && Number.isFinite(item.examples);
  const dateIsValid = (item: unknown) => isRecord(item) && typeof item.date === 'string'
    && typeof item.examples === 'number' && Number.isFinite(item.examples);
  if (!value.feature_aggregates.every(featureIsValid)
    || !value.repository_distribution.every(groupIsValid)
    || !value.collection_timeline.every(dateIsValid)) {
    throw new Error('Dataset summary response contained invalid aggregate values.');
  }
  return value as unknown as DatasetSummaryResponse;
}

let systemSnapshotInFlight: Promise<SystemSnapshot> | null = null;

/** Deduplicates concurrent initial/StrictMode refreshes of the three system endpoints. */
export function getSystemSnapshot(): Promise<SystemSnapshot> {
  if (systemSnapshotInFlight) return systemSnapshotInFlight;
  systemSnapshotInFlight = Promise.all([
    requestTimed('/health', validateHealth),
    requestTimed('/ready', validateReadiness),
    requestTimed('/api/v1/model-info', validateModelInfo),
    requestTimed('/api/v1/dataset-summary', validateDatasetSummary),
  ]).then(([health, readiness, model_info, dataset_summary]) => ({ health, readiness, model_info, dataset_summary, checked_at: new Date().toISOString() }))
    .finally(() => { systemSnapshotInFlight = null; });
  return systemSnapshotInFlight;
}

export async function submitPrediction(payload: PredictionRequest): Promise<PredictionResponse> {
  let response: Response;
  try {
    response = await fetch(`${apiBaseUrl}/api/v1/predict`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(12000),
    });
  } catch (error) {
    throw new ApiError(error instanceof Error ? error.message : 'The prediction request could not reach the API.', 0, 'NETWORK_ERROR');
  }
  const body: unknown = await response.json().catch(() => null);
  if (!response.ok) throw errorFromPayload(body, response.status);
  return validatePredictionResponse(body);
}
