import { useMemo, useState } from 'react';
import { ArrowRight, GitCompareArrows } from 'lucide-react';
import { EmptyState } from '../components/EmptyState';
import { PageHeading } from '../components/PageHeading';
import { ChartPanel, FeatureComparisonChart, ProbabilityComparisonChart } from '../components/DataCharts';
import type { SavedPrediction } from '../types/api';

const featureFields = [
  'files_changed', 'lines_added', 'commit_severity', 'developer_commits', 'avg_files_per_commit',
  'developer_conflicts', 'activity_score', 'import_count', 'dependency_conflicts', 'coverage',
  'branch_commits', 'branch_files_changed', 'branch_conflicts', 'branch_risk_score',
  'pattern_frequency', 'pattern_conflicts', 'dependency_risk', 'pattern_risk',
] as const;

export function CompareRuns({ records }: { records: SavedPrediction[] }) {
  const [leftId, setLeftId] = useState('');
  const [rightId, setRightId] = useState('');
  const left = useMemo(() => records.find((record) => record.id === leftId) ?? null, [records, leftId]);
  const right = useMemo(() => records.find((record) => record.id === rightId) ?? null, [records, rightId]);
  const differences = left && right ? featureFields.filter((field) => left.request[field] !== right.request[field]) : [];

  return <>
    <PageHeading eyebrow="RUN COMPARISON" title="Compare Runs" description="Compare two saved API responses and their original request values side by side." />
    {records.length < 2 ? <section className="surface-card compare-panel"><EmptyState icon={GitCompareArrows} title="Two saved predictions are needed">Create two successful predictions in Collision Studio. Only actual API responses stored in this browser can be compared.</EmptyState></section> : <>
      <section className="surface-card compare-panel">
        <div className="compare-selectors">
          <label className="compare-select"><span><i className="compare-marker marker-cyan" />BASELINE RUN</span><select aria-label="Select baseline run" value={leftId} onChange={(event) => setLeftId(event.target.value)}><option value="">Select saved run</option>{records.map((record) => <option key={record.id} value={record.id}>{new Date(record.saved_at).toLocaleString()} · {record.response.predicted_class} · {record.id.slice(-8)}</option>)}</select></label>
          <span className="compare-glyph"><GitCompareArrows size={19} /></span>
          <label className="compare-select"><span><i className="compare-marker marker-purple" />COMPARISON RUN</span><select aria-label="Select comparison run" value={rightId} onChange={(event) => setRightId(event.target.value)}><option value="">Select saved run</option>{records.map((record) => <option key={record.id} value={record.id}>{new Date(record.saved_at).toLocaleString()} · {record.response.predicted_class} · {record.id.slice(-8)}</option>)}</select></label>
        </div>
      </section>
      {left && right ? <section className="surface-card comparison-results">
        <div className="section-title-row"><div><span className="section-kicker">ACTUAL SAVED RESPONSES</span><h2>Prediction comparison</h2></div><span className="concept-badge">NO RE-SCORING</span></div>
        <div className="comparison-columns">
          {[left, right].map((record, index) => <div key={record.id} className={index ? 'comparison-right' : ''}>
            <span className="comparison-label">{index ? 'COMPARISON RUN' : 'BASELINE RUN'}</span><strong>{String(record.response.class_probabilities.merge_conflict)}</strong><span>Conflict probability · {record.response.predicted_class}</span><small>{record.response.prediction_label}</small><small>{new Date(record.saved_at).toLocaleString()}</small><code>{record.id}</code><small>Branch labels: {record.branch_metadata.source || 'source not labeled'} → {record.branch_metadata.target || 'target not labeled'}</small>
          </div>)}
        </div>
        <div className="comparison-probability-row"><span>Clean-merge probability</span><code>{String(left.response.class_probabilities.clean_merge)}</code><ArrowRight size={14} /><code>{String(right.response.class_probabilities.clean_merge)}</code></div>
        <div className="comparison-probability-row"><span>Risk band</span><code>Not provided by API</code><ArrowRight size={14} /><code>Not provided by API</code></div>
        <div className="chart-grid chart-grid-compare">
          <ChartPanel title="Probability comparison" subtitle="Actual class probabilities stored from the two API responses." aside={<span className="chart-tag">SAVED OUTPUT</span>}>
            <ProbabilityComparisonChart baseline={{ label: 'Baseline run', clean: left.response.class_probabilities.clean_merge, conflict: left.response.class_probabilities.merge_conflict }} comparison={{ label: 'Comparison run', clean: right.response.class_probabilities.clean_merge, conflict: right.response.class_probabilities.merge_conflict }} />
          </ChartPanel>
          <ChartPanel title="Input measurements" subtitle="Five values sent to the model; bars share one relative scale across different units." aside={<span className="chart-tag">SAVED REQUESTS</span>}>
            <FeatureComparisonChart left={left} right={right} />
          </ChartPanel>
        </div>
        <div className="changed-inputs"><h3>Input differences ({differences.length})</h3>{differences.length ? differences.map((field) => <div className="changed-input-row" key={field}><span>{field}</span><code>{left.request[field] == null ? 'Not supplied' : String(left.request[field])}</code><ArrowRight size={13} /><code>{right.request[field] == null ? 'Not supplied' : String(right.request[field])}</code></div>) : <p className="concept-note">The saved request values match across all 18 contract fields.</p>}</div>
        <p className="compare-metadata-note">Repository identity, commit SHAs, file paths, and confirmed merge results are not part of the saved prediction response.</p>
        <div className="compare-foot"><GitCompareArrows size={13} /> Probabilities and classes are copied from saved API responses; this page does not calculate a replacement score.</div>
      </section> : <div className="empty-inline">Select two different saved predictions to compare their responses.</div>}
    </>}
  </>;
}
